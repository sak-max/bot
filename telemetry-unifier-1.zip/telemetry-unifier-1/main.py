import logging
from binance.client import Client
from binance.enums import *
from binance.exceptions import BinanceAPIException
import os

# Enable Logging
logging.basicConfig(filename='trading_bot.log',
                    level=logging.INFO,
                    format='%(asctime)s %(message)s')


class BasicBot:

    def __init__(self, api_key, api_secret, testnet=True):
        self.client = Client(api_key, api_secret)

        if testnet:
            self.client.FUTURES_URL = 'https://testnet.binancefuture.com/fapi'

    def place_market_order(self, symbol, side, quantity):
        try:
            order = self.client.futures_create_order(
                symbol=symbol,
                side=SIDE_BUY if side.lower() == 'buy' else SIDE_SELL,
                type=ORDER_TYPE_MARKET,
                quantity=quantity)
            logging.info(f"Market order placed: {order}")
            return order
        except BinanceAPIException as e:
            logging.error(f"Market order error: {e}")
            return None

    def place_limit_order(self, symbol, side, quantity, price):
        try:
            order = self.client.futures_create_order(
                symbol=symbol,
                side=SIDE_BUY if side.lower() == 'buy' else SIDE_SELL,
                type=ORDER_TYPE_LIMIT,
                timeInForce=TIME_IN_FORCE_GTC,
                quantity=quantity,
                price=price)
            logging.info(f"Limit order placed: {order}")
            return order
        except BinanceAPIException as e:
            logging.error(f"Limit order error: {e}")
            return None

    # Bonus: Stop-Limit
    def place_stop_limit_order(self, symbol, side, quantity, stop_price,
                               limit_price):
        try:
            order = self.client.futures_create_order(
                symbol=symbol,
                side=SIDE_BUY if side.lower() == 'buy' else SIDE_SELL,
                type=ORDER_TYPE_STOP,
                timeInForce=TIME_IN_FORCE_GTC,
                quantity=quantity,
                price=limit_price,
                stopPrice=stop_price)
            logging.info(f"Stop-limit order placed: {order}")
            return order
        except BinanceAPIException as e:
            logging.error(f"Stop-limit order error: {e}")
            return None


# --- Run CLI Interface ---
def run_cli():
    api_key = input("Enter your API Key: ")
    api_secret = input("Enter your API Secret: ")
    bot = BasicBot(api_key, api_secret)

    while True:
        order_type = input("Enter order type (market/limit/stop): ").lower()
        symbol = input("Enter symbol (e.g. BTCUSDT): ").upper()
        side = input("Enter side (buy/sell): ").lower()
        quantity = float(input("Enter quantity: "))

        if order_type == 'market':
            result = bot.place_market_order(symbol, side, quantity)
        elif order_type == 'limit':
            price = input("Enter limit price: ")
            result = bot.place_limit_order(symbol, side, quantity, price)
        elif order_type == 'stop':
            stop_price = input("Enter stop price: ")
            limit_price = input("Enter limit price: ")
            result = bot.place_stop_limit_order(symbol, side, quantity,
                                                stop_price, limit_price)
        else:
            print("Invalid order type.")
            continue

        if result:
            print("Order placed successfully!")
        else:
            print("Order failed. Check logs.")


if __name__ == '__main__':
    run_cli()
